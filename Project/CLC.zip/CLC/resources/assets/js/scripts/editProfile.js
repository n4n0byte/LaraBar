$(document).ready(){
    const $menuButton = $('.menu-button');
const $navDropdown = $('#nav-dropdown');

$menuButton.on('click', () => {
    $navDropdown.toggle();
});

});