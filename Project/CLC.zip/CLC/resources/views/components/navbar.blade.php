<nav class="navbar navbar-default sticky-top" style="background-color: rgba(255,255,255,.8);">
    <ul class="nav justify-content-end">
        {{$slot}}
    </ul>
</nav>
