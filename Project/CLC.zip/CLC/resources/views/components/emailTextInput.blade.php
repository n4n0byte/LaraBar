<div class="form-group">
    <label class="label">Email</label>
    <input class="form-control" max="200" name="{{$name or 'email'}}" value="{{$data or ''}}" type="email" title="Email" required>
</div>