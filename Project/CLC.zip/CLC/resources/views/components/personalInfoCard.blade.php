
<div class="card card-outline-secondary">

    <div class="card-header bg-info">
        <h3>Personal Details {{$slot}}</h3>

    </div>

    <div class="card-body card-block bg-faded">
        <span><h5>Name:</h5></span> {{$firstName}}  {{$lastName}} <br>
        <span><h5>Email:</h5></span>  {{$email}}<br>
    </div>
</div>

