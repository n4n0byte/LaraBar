{{--version 1.0--}}
{{--Ali--}}
{{--CST-256--}}
{{--January 24, 2018--}}
{{--This assignment was completed in collaboration with Connor Low, Ali Cooper.--}}
{{--We used source code from the following websites to complete this assignment: N/A--}}
<li class="nav-item">
    <a class="nav-link" href="/CLC/{{$uri}}">{{$title}}</a>
</li>

