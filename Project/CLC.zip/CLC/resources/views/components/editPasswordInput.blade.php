<div class="form-group">
    <label class="label">Password</label>
    <input type="password" class="form-control" name="password" cols="40" rows="5" value="{{$data or ''}}">
</div>
