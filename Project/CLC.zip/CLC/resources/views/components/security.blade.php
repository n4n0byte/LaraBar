@php
$user = session()->get('user');
@endphp