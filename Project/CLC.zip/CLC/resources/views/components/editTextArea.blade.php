<div class="form-group">
    <label for="{{$id or ''}}" class="label">{{$label}}</label>
    <textarea id="" class="form-control" name={{$name}} cols="40" rows="5" >{{$data or ''}}</textarea>
</div>
