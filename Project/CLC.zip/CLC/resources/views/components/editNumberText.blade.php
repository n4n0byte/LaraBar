<div class="form-group">
    <label for="{{$id or ""}}" class="label">{{$label}}</label>
    <input id="{{$id or ""}}" type="number" class="form-control" name="{{$name}}" value="{{$data or ''}}">
</div>
