<table id="admin" class="table table-bordered table-hover" style="background-color: rgba(255,255,255,.8); ">
        <tr>
            <th>ID</th>
            <th>EMAIL</th>
            <th>Suspend</th>
            <th>Delete</th>
            <th>Delete</th>
        </tr>
        {{$slot}}
</table>