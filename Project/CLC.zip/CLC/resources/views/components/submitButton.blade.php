<div class="form-submit">
    <input value="{{$title or "Submit"}}"  class="btn btn-outline-primary btn-block" type="submit">
</div>