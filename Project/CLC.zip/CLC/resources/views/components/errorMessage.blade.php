<div class="badge-warning center-message-small">
    <div class="title">
        <h5>Confirmation:</h5>
    </div>
    <div class="content">
        <p>{{$message}}.</p>
    </div>
</div>