<?php
/*
version 0.2

Connor
CST-256
January 24, 2018
This assignment was completed in collaboration with Connor Low, Ali Cooper.
We used source code from the following websites to complete this assignment: N/A
*/

?>
<h1>Error in form</h1>
<a href="./login">login</a>
<a href="./register">register</a>
