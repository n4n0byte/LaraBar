<?php return array (
  'appstract/laravel-blade-directives' => 
  array (
    'providers' => 
    array (
      0 => 'Appstract\\BladeDirectives\\BladeDirectivesServiceProvider',
    ),
  ),
  'appstract/laravel-bootstrap-components' => 
  array (
    'providers' => 
    array (
      0 => 'Appstract\\BootstrapComponents\\BootstrapComponentsServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
);