<?php
/**
 * Created by PhpStorm.
 * User: George
 * Date: 2/4/2018
 * Time: 4:25 PM
 */

namespace App\Services\Data;


class UserEmploymentHistoryDataAccessService {

}