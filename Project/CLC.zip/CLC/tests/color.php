<html>
<div class="container">
    <div class="panel">
        <p>panel</p>
    </div>
    <div class="accent">
        <p>accent</p>
        <p class="accentS">shadow</p>
    </div>
    <div class="interactB">
        <p>interact</p>
        <p class="interact">text</p>
    </div>
    <div class="interactBF">
        <p>interactFade</p>
        <p class="interactF">text</p>
    </div>
    <div class="note">
        <p>note</p>
        <p class="noteT">text</p>
    </div>
    <div class="warn">
        <p>warn</p>
    </div>
</div>
</html>